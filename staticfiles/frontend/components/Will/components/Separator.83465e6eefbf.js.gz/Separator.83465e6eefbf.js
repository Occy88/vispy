import React from 'react';

export default function(props) {
  return (
    <div className="content has-text-centered">
      <p className="is-size-5">~</p>
    </div>
  );
}
