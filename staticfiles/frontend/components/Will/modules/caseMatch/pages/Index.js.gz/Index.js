import React from 'react';

import Title from '../../../components/Title';

export default function() {
  return (
    <div className="section">
      <Title
        title="Case matches"
        subtitle="Customer application matches"
      />
    </div>
  );
}
