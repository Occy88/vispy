const languages = {
    'en-us': {
        filter: "filter"
    },
    'fr': {
        filter: "filtre"
    },
    'it': {
        filter: "filtro"
    },
    'es': {
        filter: "filtro"
    },

};
export default languages;