const languages = {
    'en-us': {
        logout: "logout",
        knn: "knn",

    },
    'fr': {
        logout: "logout",
        knn: "knn",
    },
    'it': {
        logout: "logout",
        knn: "knn",
    },
    'es': {
        logout: "logout",
        knn: "knn",
    },

};
export default languages;