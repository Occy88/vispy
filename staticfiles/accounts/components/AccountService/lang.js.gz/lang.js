const languages = {
    'en-us': {
        RegisterDelivery: "Register Delivery",
        scan:"scan",
        stock:"stock",
    },
    'fr': {
RegisterDelivery: "Register Delivery",
        scan:"scan",
        stock:"stock",    },
    'it': {
RegisterDelivery: "Register Delivery",
        scan:"scan",
        stock:"stock",    },
    'es': {
RegisterDelivery: "Register Delivery",
        scan:"scan",
        stock:"stock",    },

};
export default languages;